/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          red: '#cc0000',
          'red-light': '#ff2222',
          'red-dark': '#990000',
          'red-glow': '#e8000022',
          black: '#0a0a0a',
          'black-2': '#111111',
          'black-3': '#1a1a1a',
          'black-4': '#222222',
          silver: '#e8e8e8',
          'silver-2': '#c0c0c0',
          'silver-3': '#8a8a8a',
          'silver-4': '#555555',
        },
      },
      fontFamily: {
        sans: ['Montserrat', 'sans-serif'],
      },
      animation: {
        'fade-in-up': 'fadeInUp 0.7s ease-out forwards',
        'fade-in': 'fadeIn 0.5s ease-out forwards',
        'glow-pulse': 'glowPulse 3s ease-in-out infinite',
        'slide-in-left': 'slideInLeft 0.6s ease-out forwards',
      },
      keyframes: {
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(28px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        glowPulse: {
          '0%, 100%': { boxShadow: '0 0 20px #cc000044, 0 0 40px #cc000022' },
          '50%': { boxShadow: '0 0 40px #cc000088, 0 0 80px #cc000044' },
        },
        slideInLeft: {
          '0%': { opacity: '0', transform: 'translateX(-24px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
      },
      dropShadow: {
        red: '0 0 16px #cc000088',
        silver: '0 0 8px #e8e8e844',
      },
    },
  },
  plugins: [],
};
