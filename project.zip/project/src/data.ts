export type MenuItem = {
  name: string;
  desc?: string;
  price: number;
  badge?: string;
};

export type MenuCategory = {
  id: string;
  title: string;
  icon: string;
  items: MenuItem[];
};

export const menu: MenuCategory[] = [
  {
    id: 'sis-cevap',
    title: 'Šiš ćevap',
    icon: 'Beef',
    items: [
      { name: 'Šiš ćevap — mali', desc: '2 komada', price: 7.5 },
      { name: 'Šiš ćevap — srednji', desc: '3 komada', price: 10 },
      { name: 'Šiš ćevap — veliki', desc: '4 komada', price: 12.5 },
    ],
  },
  {
    id: 'sudzukice',
    title: 'Domaće sudžukice',
    icon: 'Sausage',
    items: [
      { name: 'Sudžukice — male', desc: '2 komada', price: 7.5 },
      { name: 'Sudžukice — srednje', desc: '3 komada', price: 10 },
      { name: 'Sudžukice — velike', desc: '4 komada', price: 12.5 },
    ],
  },
  {
    id: 'piletina',
    title: 'Piletina s zarom',
    icon: 'Drumstick',
    items: [
      { name: 'Piletina s zarom — mala', desc: 'Sočno pileće bijelo meso s roštilja', price: 9.5 },
      { name: 'Piletina s zarom — velika', desc: 'Sočno pileće bijelo meso s roštilja', price: 13.5 },
    ],
  },
  {
    id: 'kombinacije',
    title: 'Kombinacije',
    icon: 'UtensilsCrossed',
    items: [
      {
        name: 'Mala kombinacija',
        desc: '1 šiš ćevap, 3 ćevapa',
        price: 8.5,
      },
      {
        name: 'Srednja kombinacija',
        desc: '1 šiš ćevap, 1 sudžukica, 3 ćevapa',
        price: 11.5,
      },
      {
        name: 'Velika kombinacija',
        desc: '1 šiš ćevap, 1 sudžukica, 6 ćevapa',
        price: 15.5,
      },
    ],
  },
  {
    id: 'pladanj',
    title: 'Pladanj za 3–4 osobe',
    icon: 'Pizza',
    items: [
      {
        name: 'Veliki pladanj',
        desc: '2 hamburgera, 2 piletine, 2 šiš ćevapa, 2 sudžukice, 12 ćevapa, 2 kajmaka, 2 ajvara, 2 porcije pomfrita, 3 somuna',
        price: 46,
        badge: 'Za družinu',
      },
    ],
  },
  {
    id: 'prilozi',
    title: 'Prilozi & dodaci',
    icon: 'Soup',
    items: [
      { name: 'Pomfrit', desc: 'Hrskavo pečeni krompir', price: 3.5 },
      { name: 'Ajvar', desc: 'Domaći, pikantan', price: 2 },
      { name: 'Kajmak', desc: 'Kremasti, domaći', price: 2 },
      { name: 'Salata od kupusa', desc: 'Svježa i osvježavajuća', price: 2 },
      { name: 'Somun', desc: 'Toplo pečen na žaru', price: 1.5 },
      { name: 'Kecap', price: 0.5 },
      { name: 'Majoneza', price: 0.5 },
    ],
  },
  {
    id: 'pica',
    title: 'Piće',
    icon: 'CupSoda',
    items: [
      { name: 'Pivo', desc: 'Točeno u krigli', price: 3 },
      { name: 'Gazirana voda', price: 2 },
      { name: 'Sokovi', desc: 'Razni voćni sokovi', price: 2.5 },
    ],
  },
];

export const locations = [
  {
    name: 'Gyros Travnički Ćevap — Split',
    address: 'Ul. Domovinskog rata 57, 21000 Split, Hrvatska',
    phone: '021 383 052',
    phoneHref: '+385021383052',
    hours: 'Pon–Ned: 09:00 – 00:00',
    mapEmbed:
      'https://www.google.com/maps?q=Ul.+Domovinskog+rata+57,+21000+Split,+Croatia&output=embed',
  },
  {
    name: 'Gyros Travnički Ćevap — Kaštel Lukšić',
    address: 'Ivana Pavla II 203, 21215 Kaštel Lukšić, Hrvatska',
    phone: '021 781 255',
    phoneHref: '+385021781255',
    hours: 'Pon–Ned: 09:00 – 23:00',
    mapEmbed:
      'https://www.google.com/maps?q=Ivana+Pavla+II+203,+21215+Ka%C5%A1tel+Luk%C5%A1i%C4%87,+Croatia&output=embed',
  },
];

export const contactEmail = 'info@gyrostravnickicevap.hr';
