import { Star, UtensilsCrossed, MapPin, ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/6210755/pexels-photo-6210755.jpeg?auto=compress&cs=tinysrgb&w=1920"
          alt="Meso na žaru"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-brand-black/85 via-brand-black/65 to-brand-black" />
        <div className="absolute inset-0 bg-gradient-to-r from-brand-black/90 to-transparent" />
      </div>

      {/* Red glow accents */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-[8%] top-[18%] h-72 w-72 rounded-full bg-brand-red/20 blur-3xl animate-glow-pulse" />
        <div className="absolute right-[12%] bottom-[22%] h-96 w-96 rounded-full bg-brand-red-dark/15 blur-3xl animate-glow-pulse [animation-delay:1.5s]" />
      </div>

      {/* Content */}
      <div className="container-x relative z-10 flex min-h-screen flex-col justify-center px-6 pt-24 md:px-12">
        <div className="max-w-3xl">
          <div className="mb-6 flex items-center gap-3 animate-fade-in-up">
            <div className="red-divider" />
            <span className="eyebrow">Tradicija od 1965.</span>
          </div>

          <h1 className="text-6xl font-black uppercase leading-[0.95] tracking-tight text-white animate-fade-in-up [animation-delay:0.1s] md:text-8xl lg:text-9xl">
            Travnički
            <br />
            <span className="text-brand-red glow-red">Ćevap</span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-brand-silver-2 animate-fade-in-up [animation-delay:0.2s]">
            Originalni recept prenošen generacijama. Sočni ćevapi s roštilja,
            domaće sudžukice i kebab u somunu — sve pečeno na žaru, baš kako se
            radi u Travniku već decenijama.
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-4 animate-fade-in-up [animation-delay:0.3s]">
            <a href="#menu" className="btn-primary">
              <UtensilsCrossed className="h-4 w-4" />
              Pogledaj meni
            </a>
            <a href="#locations" className="btn-ghost">
              <MapPin className="h-4 w-4" />
              Naše lokacije
            </a>
          </div>

          {/* Stats */}
          <div className="mt-16 flex flex-wrap gap-10 animate-fade-in-up [animation-delay:0.4s]">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-black text-white">60</span>
                <span className="text-2xl font-bold text-brand-red">+</span>
              </div>
              <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-brand-silver-3">Godina tradicije</p>
            </div>
            <div className="border-l border-white/10 pl-10">
              <div className="flex items-baseline gap-2">
                <Star className="h-6 w-6 fill-brand-red text-brand-red" />
                <span className="text-4xl font-black text-white">4.9</span>
              </div>
              <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-brand-silver-3">Ocjena gostiju</p>
            </div>
            <div className="border-l border-white/10 pl-10">
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-black text-white">2</span>
              </div>
              <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-brand-silver-3">Restorana</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-fade-in [animation-delay:0.8s]">
        <ChevronDown className="h-6 w-6 animate-bounce text-brand-silver-3" />
      </div>
    </section>
  );
}
