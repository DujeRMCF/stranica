import { useState } from 'react';
import { menu } from '../data';
import * as Icons from 'lucide-react';
import type { ComponentType } from 'react';

type IconType = ComponentType<{ className?: string; strokeWidth?: number }>;

function getIcon(name: string): IconType {
  const lib = Icons as unknown as Record<string, IconType>;
  return lib[name] ?? Icons.UtensilsCrossed;
}

export default function MenuSection() {
  const [active, setActive] = useState(menu[0].id);
  const current = menu.find((c) => c.id === active) ?? menu[0];

  return (
    <section id="menu" className="section-pad bg-brand-black-2 relative overflow-hidden">
      {/* Background glow */}
      <div className="pointer-events-none absolute inset-0 opacity-10">
        <div className="absolute left-0 top-0 h-96 w-96 rounded-full bg-brand-red blur-3xl" />
        <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-brand-red-dark blur-3xl" />
      </div>

      <div className="container-x relative z-10">
        {/* Heading */}
        <div className="mx-auto mb-12 max-w-3xl text-center">
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="red-divider" />
            <span className="eyebrow">Naš meni</span>
            <div className="red-divider" />
          </div>
          <h2 className="section-heading">
            Sve što vam treba za savršen obrok
          </h2>
          <p className="mt-4 text-brand-silver-3">
            Od klasičnog kebaba u somunu do bogatog pladnja za cijelu družinu.
            Cijene su u eurima (€).
          </p>
        </div>

        {/* Category tabs */}
        <div className="mb-12 flex flex-wrap justify-center gap-2 md:gap-3">
          {menu.map((cat) => {
            const Icon = getIcon(cat.icon);
            return (
              <button
                key={cat.id}
                onClick={() => setActive(cat.id)}
                className={`group flex items-center gap-2 rounded-sm px-5 py-2.5 text-xs font-bold uppercase tracking-wider transition-all duration-300 md:text-sm ${
                  active === cat.id
                    ? 'bg-brand-red text-white shadow-lg shadow-brand-red/30'
                    : 'bg-white/5 text-brand-silver-3 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4" />
                {cat.title}
              </button>
            );
          })}
        </div>

        {/* Items */}
        <div className="mx-auto max-w-4xl">
          <div key={current.id} className="animate-fade-in-up">
            <h3 className="mb-8 text-center text-2xl font-black uppercase tracking-wider text-brand-red">
              {current.title}
            </h3>
            <div className="grid gap-3">
              {current.items.map((item, i) => (
                <div
                  key={i}
                  className="group flex items-start justify-between gap-4 rounded-sm border border-white/10 bg-brand-black p-5 transition-all duration-300 hover:border-brand-red/40 hover:bg-brand-black-3"
                >
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3">
                      <h4 className="text-lg font-bold text-white">{item.name}</h4>
                      {item.badge && (
                        <span className="rounded-sm bg-brand-red/20 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-brand-red">
                          {item.badge}
                        </span>
                      )}
                    </div>
                    {item.desc && (
                      <p className="mt-1.5 text-sm text-brand-silver-3">{item.desc}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-3 whitespace-nowrap">
                    <div className="hidden flex-1 border-b border-dashed border-white/15 sm:block" />
                    <span className="text-2xl font-black text-brand-red">
                      {item.price.toFixed(2)}
                    </span>
                    <span className="text-xs font-semibold text-brand-silver-4">€</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>


      </div>
    </section>
  );
}
