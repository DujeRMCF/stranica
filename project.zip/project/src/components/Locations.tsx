import { MapPin, Phone, Clock, ExternalLink } from 'lucide-react';
import { locations } from '../data';

export default function Locations() {
  return (
    <section id="locations" className="section-pad bg-brand-black-2">
      <div className="container-x">
        {/* Heading */}
        <div className="mx-auto mb-12 max-w-3xl text-center">
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="red-divider" />
            <span className="eyebrow">Lokacije</span>
            <div className="red-divider" />
          </div>
          <h2 className="section-heading">
            Posjetite nas na dvije lokacije
          </h2>
          <p className="mt-4 text-brand-silver-3">
            Naši restorani su otvoreni svaki dan. Dođite, nazovite ili naručite.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {locations.map((loc, i) => (
            <div
              key={i}
              className="card-dark overflow-hidden hover:-translate-y-1 hover:border-brand-red/40 hover:shadow-xl hover:shadow-brand-red/10"
            >
              {/* Map */}
              <div className="relative h-72 w-full overflow-hidden md:h-80">
                <iframe
                  src={loc.mapEmbed}
                  title={loc.name}
                  className="h-full w-full border-0 grayscale-[0.3] transition-all duration-500 hover:grayscale-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                />
              </div>

              {/* Info */}
              <div className="p-6 md:p-8">
                <div className="mb-4 flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-sm bg-brand-red text-sm font-black text-white">
                    {i + 1}
                  </span>
                  <h3 className="text-xl font-bold text-white">{loc.name}</h3>
                </div>

                <ul className="space-y-3">
                  <li className="flex items-start gap-3 text-brand-silver-2">
                    <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-brand-red" />
                    <span>{loc.address}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Phone className="mt-0.5 h-5 w-5 shrink-0 text-brand-red" />
                    <a
                      href={`tel:${loc.phoneHref}`}
                      className="font-semibold text-white transition-colors hover:text-brand-red"
                    >
                      {loc.phone}
                    </a>
                  </li>
                  <li className="flex items-start gap-3 text-brand-silver-2">
                    <Clock className="mt-0.5 h-5 w-5 shrink-0 text-brand-red" />
                    <span>{loc.hours}</span>
                  </li>
                </ul>

                <a
                  href={loc.mapEmbed.replace('output=embed', 'output=classic') || `https://www.google.com/maps?q=${encodeURIComponent(loc.address)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-ghost mt-6 w-full"
                >
                  <ExternalLink className="h-4 w-4" />
                  Otvori u Google Maps
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
