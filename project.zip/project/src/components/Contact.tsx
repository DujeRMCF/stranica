import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';
import { locations, contactEmail } from '../data';

export default function Contact() {
  return (
    <section id="contact" className="section-pad bg-brand-black relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 opacity-10">
        <div className="absolute right-0 top-0 h-96 w-96 rounded-full bg-brand-red blur-3xl" />
      </div>

      <div className="container-x relative z-10">
        {/* Heading */}
        <div className="mx-auto mb-12 max-w-3xl text-center">
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="red-divider" />
            <span className="eyebrow">Kontakt</span>
            <div className="red-divider" />
          </div>
          <h2 className="section-heading">
            Javite nam se
          </h2>
          <p className="mt-4 text-brand-silver-3">
            Za narudžbe, rezervacije ili pitanja — tu smo za vas.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Contact info */}
          <div className="space-y-4">
            {locations.map((loc, i) => (
              <div
                key={i}
                className="card-dark p-6 transition-colors duration-300 hover:border-brand-red/40"
              >
                <h3 className="mb-4 text-lg font-bold text-white">
                  {loc.name}
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-sm bg-brand-red/15">
                      <Phone className="h-5 w-5 text-brand-red" />
                    </div>
                    <a
                      href={`tel:${loc.phoneHref}`}
                      className="font-semibold text-white transition-colors hover:text-brand-red"
                    >
                      {loc.phone}
                    </a>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-sm bg-brand-red/15">
                      <MapPin className="h-5 w-5 text-brand-red" />
                    </div>
                    <span className="text-brand-silver-2">{loc.address}</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-sm bg-brand-red/15">
                      <Clock className="h-5 w-5 text-brand-red" />
                    </div>
                    <span className="text-brand-silver-2">{loc.hours}</span>
                  </li>
                </ul>
              </div>
            ))}

            {/* Email */}
            <div className="card-dark p-6 transition-colors duration-300 hover:border-brand-red/40">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-sm bg-brand-red/15">
                  <Mail className="h-5 w-5 text-brand-red" />
                </div>
                <a
                  href={`mailto:${contactEmail}`}
                  className="font-semibold text-white transition-colors hover:text-brand-red"
                >
                  {contactEmail}
                </a>
              </div>
            </div>
          </div>

          {/* Contact form */}
          <div className="card-dark p-6 md:p-8">
            <h3 className="mb-6 text-xl font-bold text-white">Pošaljite poruku</h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                form.reset();
                alert('Hvala! Vaša poruka je poslana. Javit ćemo vam se uskoro.');
              }}
              className="space-y-4"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <input
                  required
                  type="text"
                  placeholder="Ime i prezime"
                  className="w-full rounded-sm border border-white/10 bg-brand-black px-4 py-3 text-white placeholder-brand-silver-4 outline-none transition-colors focus:border-brand-red focus:bg-brand-black-3"
                />
                <input
                  required
                  type="tel"
                  placeholder="Broj telefona"
                  className="w-full rounded-sm border border-white/10 bg-brand-black px-4 py-3 text-white placeholder-brand-silver-4 outline-none transition-colors focus:border-brand-red focus:bg-brand-black-3"
                />
              </div>
              <textarea
                required
                rows={5}
                placeholder="Vaša poruka..."
                className="w-full resize-none rounded-sm border border-white/10 bg-brand-black px-4 py-3 text-white placeholder-brand-silver-4 outline-none transition-colors focus:border-brand-red focus:bg-brand-black-3"
              />
              <button type="submit" className="btn-primary w-full">
                <Send className="h-4 w-4" />
                Pošalji poruku
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
