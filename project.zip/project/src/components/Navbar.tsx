import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';

const links = [
  { label: 'O nama', href: '#about' },
  { label: 'Meni', href: '#menu' },
  { label: 'Galerija', href: '#gallery' },
  { label: 'Lokacije', href: '#locations' },
  { label: 'Kontakt', href: '#contact' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-brand-black/95 shadow-lg shadow-black/50 backdrop-blur-md'
          : 'bg-gradient-to-b from-brand-black/80 to-transparent'
      }`}
    >
      <nav className="container-x flex items-center justify-between px-6 py-3 md:px-12">
        {/* Logo */}
        <a href="#home" className="group flex items-center gap-3">
          <img
            src="/logo.jpg"
            alt="Gyros Travnički Ćevap"
            className="h-12 w-12 rounded-full object-cover ring-2 ring-brand-red/50 transition-all duration-300 group-hover:ring-brand-red group-hover:shadow-red md:h-14 md:w-14"
          />
          <div className="flex flex-col leading-none">
            <span className="text-lg font-black uppercase tracking-wider text-white">
              Gyros
            </span>
            <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-brand-red">
              Travnički Ćevap
            </span>
          </div>
        </a>

        {/* Desktop links */}
        <ul className="hidden items-center gap-8 lg:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="group relative text-sm font-semibold uppercase tracking-wide text-brand-silver transition-colors hover:text-white"
              >
                {l.label}
                <span className="absolute -bottom-1.5 left-0 h-0.5 w-0 bg-brand-red transition-all duration-300 group-hover:w-full" />
              </a>
            </li>
          ))}
        </ul>

        {/* Mobile toggle */}
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex h-10 w-10 items-center justify-center rounded-sm text-white transition-colors hover:bg-white/10 lg:hidden"
          aria-label="Meni"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden bg-brand-black/98 backdrop-blur-md transition-all duration-400 lg:hidden ${
          open ? 'max-h-96 border-t border-white/10' : 'max-h-0'
        }`}
      >
        <ul className="flex flex-col gap-1 px-6 py-4">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block rounded-sm px-4 py-3 text-base font-semibold uppercase tracking-wide text-brand-silver transition-colors hover:bg-white/10 hover:text-white"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </header>
  );
}
