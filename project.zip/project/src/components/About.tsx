import { Flame, Heart, Award, Clock } from 'lucide-react';

const features = [
  {
    icon: Flame,
    title: 'Pečeno na žaru',
    text: 'Svaki komad mesa se peče na prirodnom žaru, na temperaturi koja čuva sočnost i bogatstvo ukusa.',
  },
  {
    icon: Heart,
    title: 'Domaći sastojci',
    text: 'Koristimo samo svježe meso od provjerenih lokalnih dobavljača i domaće začine bez konzervansa.',
  },
  {
    icon: Award,
    title: 'Originalni recept',
    text: 'Recept za Travnički ćevap se prenosi s generacije na generaciju od 1965. godine — nepromijenjen.',
  },
  {
    icon: Clock,
    title: 'Uvijek svježe',
    text: 'Ćevapi se prave ručno, svako jutro. Nikakvo zamrzavanje, nikakvo podgrijavanje — samo svježe.',
  },
];

export default function About() {
  return (
    <section id="about" className="section-pad bg-brand-black">
      <div className="container-x">
        {/* Heading */}
        <div className="mx-auto mb-16 max-w-3xl text-center">
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="red-divider" />
            <span className="eyebrow">O nama</span>
            <div className="red-divider" />
          </div>
          <h2 className="section-heading">
            Tradicija koja se osjeća u svakom zalogaju
          </h2>
        </div>

        {/* Story + image */}
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="relative">
            <div className="overflow-hidden rounded-sm border border-white/10 shadow-2xl shadow-black/50">
              <img
                src="https://images.pexels.com/photos/6759537/pexels-photo-6759537.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Ćevapi na roštilju"
                className="h-[480px] w-full object-cover transition-transform duration-700 hover:scale-105"
              />
            </div>
            {/* Floating badge */}
            <div className="absolute -bottom-6 -right-6 flex h-32 w-32 flex-col items-center justify-center rounded-sm bg-brand-red text-white shadow-xl shadow-brand-red/40 md:-right-8">
              <span className="text-4xl font-black leading-none">1965</span>
              <span className="mt-1 text-[10px] font-bold uppercase tracking-wider">
                Tradicija
              </span>
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-white md:text-3xl">
              Priča o Travničkom ćevapu
            </h3>
            <div className="mt-6 space-y-4 text-base leading-relaxed text-brand-silver-2">
              <p>
                Travnički ćevap nisu samo jelo — oni su dio identiteta grada
                Travnika. Pravi Travnički ćevap se pravi od pažljivo odabranog
                junetog i ovčjeg mesa, mljevenog na kamenom mlinskom kamenu, uz
                dodatak soli i tajne mješavine začina koju naša porodica čuva
                generacijama.
              </p>
              <p>
                Meso se nikada ne preradi. Oblikuje se ručno, peče na žaru
                zagrijanom na pravu temperaturu, i služi u toplo pečenom somunu
                uz domaće priloge — kajmak, ajvar i svježu salatu od kupusa.
              </p>
              <p>
                Ono što nas izdvaja jeste dosljednost. Svaki ćevap koji izađe
                sa našeg roštilja ima isti ukus kao i onaj prije šezdeset
                godina. To je obećanje koje dajemo svakom gostu.
              </p>
            </div>

            <div className="mt-8 flex items-center gap-4">
              <div className="flex -space-x-3">
                {[
                  'https://images.pexels.com/photos/3814446/pexels-photo-3814446.jpeg?auto=compress&cs=tinysrgb&w=100',
                  'https://images.pexels.com/photos/3777943/pexels-photo-3777943.jpeg?auto=compress&cs=tinysrgb&w=100',
                  'https://images.pexels.com/photos/3759079/pexels-photo-3759079.jpeg?auto=compress&cs=tinysrgb&w=100',
                ].map((src, i) => (
                  <img
                    key={i}
                    src={src}
                    alt=""
                    className="h-12 w-12 rounded-full border-2 border-brand-black object-cover"
                  />
                ))}
              </div>
              <p className="text-sm text-brand-silver-3">
                <span className="font-bold text-white">Hilja zadovoljnih gostiju</span>
                <br />
                kroz šest decenija rada
              </p>
            </div>
          </div>
        </div>

        {/* Features grid */}
        <div className="mt-20 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div
              key={f.title}
              className="card-dark group p-8 hover:-translate-y-1 hover:border-brand-red/50 hover:shadow-lg hover:shadow-brand-red/10"
            >
              <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-sm bg-brand-red/10 transition-colors duration-300 group-hover:bg-brand-red">
                <f.icon className="h-7 w-7 text-brand-red transition-colors duration-300 group-hover:text-white" />
              </div>
              <h4 className="text-lg font-bold text-white">{f.title}</h4>
              <p className="mt-3 text-sm leading-relaxed text-brand-silver-3">{f.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
