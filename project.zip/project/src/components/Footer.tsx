import { Phone, Mail, MapPin, Facebook, Instagram } from 'lucide-react';
import { locations, contactEmail } from '../data';

const navLinks = [
  { label: 'O nama', href: '#about' },
  { label: 'Meni', href: '#menu' },
  { label: 'Galerija', href: '#gallery' },
  { label: 'Lokacije', href: '#locations' },
  { label: 'Kontakt', href: '#contact' },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-brand-black">
      <div className="container-x px-6 py-16 md:px-12">
        <div className="grid grid-cols-1 gap-10 text-center sm:grid-cols-2 lg:grid-cols-4 lg:gap-8">
          {/* Brand */}
          <div className="lg:col-span-1 flex flex-col items-center">
            <div className="flex items-center gap-3">
              <img
                src="/logo.jpg"
                alt="Gyros Travnički Ćevap"
                className="h-14 w-14 rounded-full object-cover ring-2 ring-brand-red/50"
              />
              <div className="flex flex-col leading-none">
                <span className="text-lg font-black uppercase tracking-wider text-white">Gyros</span>
                <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-brand-red">Travnički Ćevap</span>
              </div>
            </div>
            <p className="mt-5 text-sm leading-relaxed text-brand-silver-3">
              Originalni Travnički ćevap — tradicija od 1965. Pečeno na žaru, s
              ljubavlju, za vas.
            </p>
            <div className="mt-6 flex gap-3">
              <a
                href="#"
                aria-label="Facebook"
                className="flex h-10 w-10 items-center justify-center rounded-sm bg-white/5 text-brand-silver-3 transition-colors hover:bg-brand-red hover:text-white"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="#"
                aria-label="Instagram"
                className="flex h-10 w-10 items-center justify-center rounded-sm bg-white/5 text-brand-silver-3 transition-colors hover:bg-brand-red hover:text-white"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Nav */}
          <div className="flex flex-col items-center">
            <h4 className="mb-5 text-xs font-bold uppercase tracking-widest text-white">Navigacija</h4>
            <ul className="space-y-3">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-sm text-brand-silver-3 transition-colors hover:text-brand-red">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Locations */}
          <div className="flex flex-col items-center">
            <h4 className="mb-5 text-xs font-bold uppercase tracking-widest text-white">Lokacije</h4>
            <ul className="space-y-4">
              {locations.map((loc, i) => (
                <li key={i} className="space-y-1 text-center">
                  <div className="flex items-start justify-center gap-2 text-brand-silver-3">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-red" />
                    <span className="text-sm">{loc.address}</span>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <Phone className="h-4 w-4 shrink-0 text-brand-red" />
                    <a href={`tel:${loc.phoneHref}`} className="text-sm text-brand-silver-2 transition-colors hover:text-brand-red">
                      {loc.phone}
                    </a>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* Email */}
          <div className="flex flex-col items-center">
            <h4 className="mb-5 text-xs font-bold uppercase tracking-widest text-white">Email</h4>
            <a
              href={`mailto:${contactEmail}`}
              className="inline-flex items-center gap-2 text-sm text-brand-silver-2 transition-colors hover:text-brand-red"
            >
              <Mail className="h-4 w-4 text-brand-red" />
              {contactEmail}
            </a>
            <p className="mt-4 text-sm text-brand-silver-4">
              Radno vrijeme:<br />
              Split: 09:00 – 00:00<br />
              Kaštel Lukšić: 09:00 – 23:00
            </p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 md:flex-row">
          <p className="text-xs text-brand-silver-4">
            © {new Date().getFullYear()} Gyros Travnički Ćevap. Sva prava zadržana.
          </p>
          <p className="text-xs text-brand-silver-4">
            Napravljeno s ljubavlju prema tradiciji.
          </p>
        </div>
      </div>
    </footer>
  );
}
