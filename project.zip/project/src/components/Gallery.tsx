import { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

type ImageItem = { src: string; alt: string; span?: string };

const galleryImages: ImageItem[] = [
  {
    src: 'https://images.pexels.com/photos/6210755/pexels-photo-6210755.jpeg?auto=compress&cs=tinysrgb&w=1200',
    alt: 'Meso se okreće na žaru',
    span: 'md:col-span-2 md:row-span-2',
  },
  {
    src: 'https://images.pexels.com/photos/6759537/pexels-photo-6759537.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Ćevapi na roštilju',
  },
  {
    src: 'https://images.pexels.com/photos/3338497/pexels-photo-3338497.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Kobasice na žaru',
  },
  {
    src: 'https://images.pexels.com/photos/958346/pexels-photo-958346.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Roštilj u punoj akciji',
  },
  {
    src: 'https://images.pexels.com/photos/2871757/pexels-photo-2871757.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Lepinja za ćevape',
  },
  {
    src: 'https://images.pexels.com/photos/2317684/pexels-photo-2317684.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Roštilj pladanj',
    span: 'md:col-span-2',
  },
  {
    src: 'https://images.pexels.com/photos/4193883/pexels-photo-4193883.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Piletina s roštilja',
  },
  {
    src: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Meso se peče na žaru',
  },
  {
    src: 'https://images.pexels.com/photos/2233348/pexels-photo-2233348.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Ćevapi u lepinji',
  },
];

export default function Gallery() {
  const [lightbox, setLightbox] = useState<number | null>(null);

  const close = () => setLightbox(null);
  const prev = () => setLightbox((v) => (v === null ? null : (v - 1 + galleryImages.length) % galleryImages.length));
  const next = () => setLightbox((v) => (v === null ? null : (v + 1) % galleryImages.length));

  return (
    <section id="gallery" className="section-pad bg-brand-black">
      <div className="container-x">
        {/* Heading */}
        <div className="mx-auto mb-12 max-w-3xl text-center">
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="red-divider" />
            <span className="eyebrow">Galerija</span>
            <div className="red-divider" />
          </div>
          <h2 className="section-heading">
            Pogledajte naš svijet s roštilja
          </h2>
          <p className="mt-4 text-brand-silver-3">
            Od sočnih ćevapa do bogatih pladnjeva — pogledajte šta vas čeka.
          </p>
        </div>

        {/* Grid */}
        <div className="grid auto-rows-[200px] grid-cols-2 gap-4 md:grid-cols-4 md:auto-rows-[240px]">
          {galleryImages.map((img, i) => (
            <button
              key={i}
              onClick={() => setLightbox(i)}
              className={`group relative overflow-hidden rounded-sm border border-white/10 ${img.span ?? ''}`}
            >
              <img
                src={img.src}
                alt={img.alt}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-black/80 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <p className="absolute bottom-4 left-4 right-4 text-left text-sm font-semibold text-white opacity-0 transition-all duration-300 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0">
                {img.alt}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-brand-black/95 backdrop-blur-sm animate-fade-in"
          onClick={close}
        >
          <button
            onClick={close}
            className="absolute right-6 top-6 flex h-12 w-12 items-center justify-center rounded-sm bg-white/10 text-white transition-colors hover:bg-brand-red"
          >
            <X className="h-6 w-6" />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); prev(); }}
            className="absolute left-4 flex h-12 w-12 items-center justify-center rounded-sm bg-white/10 text-white transition-colors hover:bg-brand-red md:left-8"
          >
            <ChevronLeft className="h-7 w-7" />
          </button>
          <img
            src={galleryImages[lightbox].src}
            alt={galleryImages[lightbox].alt}
            onClick={(e) => e.stopPropagation()}
            className="max-h-[85vh] max-w-[90vw] rounded-sm border border-white/10 object-contain"
          />
          <button
            onClick={(e) => { e.stopPropagation(); next(); }}
            className="absolute right-4 flex h-12 w-12 items-center justify-center rounded-sm bg-white/10 text-white transition-colors hover:bg-brand-red md:right-8"
          >
            <ChevronRight className="h-7 w-7" />
          </button>
        </div>
      )}
    </section>
  );
}
